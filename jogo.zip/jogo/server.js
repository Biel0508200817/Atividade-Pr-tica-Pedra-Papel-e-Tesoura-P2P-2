const express = require("express");
const fs = require("fs");
const path = require("path");
const { WebSocketServer } = require("ws");

const app = express();
const PORT = 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

const partidasFile = "partidas.json";

// --------- CRUD para partidas ----------
function carregarPartidas() {
    if (!fs.existsSync(partidasFile)) {
        fs.writeFileSync(partidasFile, "[]");
    }
    return JSON.parse(fs.readFileSync(partidasFile));
}

function salvarPartida(partida) {
    const partidas = carregarPartidas();
    partidas.push(partida);
    fs.writeFileSync(partidasFile, JSON.stringify(partidas, null, 2));
}

app.get("/api/partidas", (req, res) => {
    res.json(carregarPartidas());
});

// ---------------------------------------

// Servidor WebSocket
const server = app.listen(PORT, () =>
    console.log(`Servidor rodando em http://localhost:${PORT}`)
);

const wss = new WebSocketServer({ server });

let players = []; // lista de conexões

wss.on("connection", (ws) => {
    console.log("Novo jogador conectado.");
    players.push(ws);

    ws.on("message", (msg) => {
        const data = JSON.parse(msg);

        // Reenvia a jogada ao outro jogador
        players.forEach((p) => {
            if (p !== ws && p.readyState === p.OPEN) {
                p.send(JSON.stringify(data));
            }
        });

        // Se a partida acabou, salva no histórico
        if (data.type === "result") {
            salvarPartida({
                jogador1: data.j1,
                jogador2: data.j2,
                vencedor: data.winner,
                data: new Date().toISOString()
            });
        }
    });

    ws.on("close", () => {
        players = players.filter((p) => p !== ws);
        console.log("Jogador desconectado.");
    });
});
