let ws;
let playerName = "";
let myMove = null;
let opponentMove = null;

function joinGame() {
    playerName = document.getElementById("playerName").value.trim();
    if (!playerName) return alert("Digite seu nome!");

    ws = new WebSocket("ws://localhost:3000");

    ws.onopen = () => {
        document.getElementById("status").innerText = "Conectado! Aguarde a jogada.";
        document.getElementById("choices").classList.remove("hidden");
    };

    ws.onmessage = (msg) => {
        const data = JSON.parse(msg.data);

        if (data.type === "move") {
            opponentMove = data.move;
            checkWinner();
        }
    };
}

function sendMove(move) {
    myMove = move;
    ws.send(JSON.stringify({ type: "move", move, player: playerName }));
    document.getElementById("status").innerText = `Você escolheu: ${move}`;
    checkWinner();
}

function checkWinner() {
    if (!myMove || !opponentMove) return;

    const rules = {
        pedra: "tesoura",
        papel: "pedra",
        tesoura: "papel"
    };

    let winner = "";

    if (myMove === opponentMove) {
        winner = "Empate";
    } else if (rules[myMove] === opponentMove) {
        winner = playerName;
    } else {
        winner = "Oponente";
    }

    document.getElementById("result").innerText =
        `Resultado: ${winner === "Empate" ? "Empate!" : "Vencedor: " + winner}`;

    ws.send(JSON.stringify({
        type: "result",
        j1: playerName,
        j2: "Oponente",
        winner
    }));

    myMove = null;
    opponentMove = null;
}
